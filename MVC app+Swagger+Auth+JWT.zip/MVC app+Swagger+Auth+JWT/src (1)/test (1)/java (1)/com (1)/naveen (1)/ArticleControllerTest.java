package com.naveen;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;

public class ArticleControllerTest extends SpringbootApplicationTests {
	@Autowired
	private WebApplicationContext webApplicationContext;
	private MockMvc mockMvc;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}

	/**
	 * test case for adding article details with one to many association
	 * @throws Exception
	 */
	@Test
	public void addArticleTest() throws Exception {

		JSONObject authorObject = new JSONObject();
		authorObject.put("authorName", "knk");

		JSONArray array = new JSONArray();

		JSONObject object = new JSONObject();
		object.put("title", "java");
		object.put("category", "developing");
		array.add(object);

		JSONObject objects = new JSONObject();
		objects.put("title", "oracle");
		objects.put("category", "database");
		array.add(objects);

		JSONObject obj = new JSONObject();
		obj.put("authorData", authorObject);
		obj.put("articleData", array);

		mockMvc.perform(post("/article/addArticles").contentType("application/json;charset=UTF-8").content(obj.toString()))
				.andExpect(status().isOk()).andExpect(content().contentType("application/json;charset=UTF-8"));
	}
	/**
	 * test case for adding articles details with wrong input values using one to many association
	 * @throws Exception
	 */
	@Test
	public void addArticleFailureTest() throws Exception {

		JSONObject authorObject = new JSONObject();
		authorObject.put("authorName", "knk");

		JSONArray array = new JSONArray();

		JSONObject articleObject = new JSONObject();
		articleObject.put("title", "java");
		articleObject.put("category", "developing");
		array.add(articleObject);

		JSONObject objects = new JSONObject();
		objects.put("title", "oracle");
		objects.put("category", "database");
		array.add(objects);

		JSONObject obj = new JSONObject();
		obj.put("authorData", authorObject);
		obj.put("articleData", array);
		
         mockMvc.perform(
				post("/article/addArticles").contentType("application/json;charset=UTF-8").content(obj.toString()))
				.andExpect(content().contentType("application/json;charset=UTF-8"))
				.andExpect(jsonPath("$.data[0].title",not("datastructures")));
	}
	
	
	
	
	
	
	
	
	/**
	 * test case for deleting article details with articleID
	 * @throws Exception
	 */
	@Test
	public void deleteArticleTest() throws Exception {
		mockMvc.perform(delete("/article/delete?articleId=6")).andExpect(status().isOk())
				.andExpect(content().contentType("application/json;charset=UTF-8"));
	}

	/**
	 * test case for deleting article records with wrong input as articleId
	 * @throws Exception
	 */
	@Test
	public void deleteArticleFailureTest() throws Exception {
		mockMvc.perform(delete("/article/delete?articleId=k")).andExpect(status().isBadRequest());
	}

	/**
	 * test case for updating article details
	 * @throws Exception
	 */
	@Test
	public void updateArticleTest() throws Exception {
		JSONObject object1 = new JSONObject();
		object1.put("authorId", 1);
		object1.put("authorName", "ramcharan");
		JSONObject object = new JSONObject();
		object.put("articleId", 1);
		object.put("title", "vidheyarama");
		object.put("category", "drama");
		object.put("author", object1);
		mockMvc.perform(put("/article/update").contentType("application/json;charset=UTF-8").content(object.toString()))
				.andExpect(status().isOk()).andExpect(content().contentType("application/json;charset=UTF-8"));

	}

	/**
	 * test case for updating article details with wrong input values
	 * @throws Exception
	 */
	@Test
	public void updateFailureArticleTest() throws Exception {
		JSONObject object1 = new JSONObject();
		object1.put("authorId", "K");
		object1.put("authorName", "ramcharan");
		JSONObject object = new JSONObject();
		object.put("articleId", 1);
		object.put("title", "vidheyarama");
		object.put("category", "drama");
		object.put("author", object1);
		mockMvc.perform(put("/article/update").contentType("application/json;charset=UTF-8").content(object.toString()))
				.andExpect(status().isBadRequest());
	}

	/**
	 * test case for add article details
	 * @throws Exception
	 */
	@Test
	public void addArticlesTest() throws Exception {
		JSONObject object1 = new JSONObject();
		object1.put("authorId", 1);
		object1.put("authorName", "naveen");
		JSONObject object = new JSONObject();
		object.put("title", "kungfupanda");
		object.put("category", "movie");
		object.put("author", object1);
		mockMvc.perform(post("/article/add").contentType("application/json;charset=UTF-8").content(object.toString()))
				.andExpect(status().isOk()).andExpect(content().contentType("application/json;charset=UTF-8"));

	}

	/**
	 *  test case for add article with wrong values
	 * @throws Exception
	 */
	@Test
	public void addArticlesFailureTest() throws Exception {
		JSONObject object1 = new JSONObject();
		object1.put("authorId", "n");
		object1.put("authorName", "naveen");
		JSONObject object = new JSONObject();
		object.put("title", "kungfupanda");
		object.put("category", "movie");
		object.put("author", object1);
		mockMvc.perform(post("/article/add").contentType("application/json;charset=UTF-8").content(object.toString()))
				.andExpect(status().isBadRequest());
	}

	/**
	 * test case for retrieving the all articles 
	 * @throws Exception
	 */
	@Test
	public void getAllArticlesTest() throws Exception {

		mockMvc.perform(get("/article/view").contentType("application/json;charset=UTF-8")).andExpect(status().isOk())
				.andExpect(content().contentType("application/json;charset=UTF-8"))
				.andExpect(jsonPath("$.status").value(200)).andExpect(jsonPath("$.data[0].articleId", is(1)))
				.andExpect(jsonPath("$.data[1].title", is("cricket")));
	}

	/**
	 * test case for retrieving the article details with wrong input value
	 * @throws Exception
	 */
	@Test
	public void getAllArticlesFailureTest() throws Exception {

		mockMvc.perform(get("/article/view")).andExpect(status().isOk())
				.andExpect(content().contentType("application/json;charset=UTF-8"))
				.andExpect(jsonPath("$.status").value(200))
				.andExpect(jsonPath("$.message").value("Getting All articles is successful"))
				.andExpect(jsonPath("$.data[0].articleId", not(2))).andExpect(jsonPath("$.data[1].title", not("ggg")));

	}
	
	
	
	
	

}