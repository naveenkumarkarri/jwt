package com.naveen;

import static org.hamcrest.CoreMatchers.not;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;

public class BookControllerTest extends SpringbootApplicationTests{
	@Autowired
	private WebApplicationContext webApplicationContext;
	private MockMvc mockMvc;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}
	/**test case for adding books details with many to many association
	 * @throws Exception
	 */
	@Test
	public void addBookTest() throws Exception {

		JSONArray array = new JSONArray();

		JSONObject shopObject = new JSONObject();
		shopObject.put("shopName", "oldbooks");
		shopObject.put("shopAddress", "vizag");
		array.add(shopObject);

		JSONObject jsonShopObject = new JSONObject();
		jsonShopObject.put("shopName", "mythri");
		jsonShopObject.put("shopAddress", "utv");
		array.add(jsonShopObject);

		JSONArray jsonArray = new JSONArray();

		JSONObject bookObject = new JSONObject();
		bookObject.put("bookName", "ramayanam");
		bookObject.put("bookCategory", "ithihas");
		jsonArray.add(bookObject);

		JSONObject jsonBookObject = new JSONObject();
		jsonBookObject.put("bookName", "mahabharath");
		jsonBookObject.put("bookCategory", "ithihas");
		jsonArray.add(jsonBookObject);

		JSONObject object = new JSONObject();
		object.put("bookShopsData", array);
		object.put("booksData", jsonArray);

		mockMvc.perform(
				post("/book/addBooks").contentType("application/json;charset=UTF-8").content(object.toString()))
				.andExpect(status().isOk()).andExpect(content().contentType("application/json;charset=UTF-8"));
				

	}
	/**test case for adding multiple books with wrong input value using many to many association
	 * @throws Exception
	 */
	@Test
	public void addBookFailureTest() throws Exception {

		JSONArray array = new JSONArray();

		JSONObject shopObject = new JSONObject();
		shopObject.put("shopName", "oldbooks");
		shopObject.put("shopAddress", "vizag");
		array.add(shopObject);

		JSONObject jsonshopObject = new JSONObject();
		jsonshopObject.put("shopName", "mythri");
		jsonshopObject.put("shopAddress", "utv");
		array.add(jsonshopObject);

		JSONArray jsonArray = new JSONArray();

		JSONObject bookObject = new JSONObject();
		bookObject.put("bookName", "ramayanam");
		bookObject.put("bookCategory", "ithihas");
		jsonArray.add(bookObject);

		JSONObject jsonBookObject = new JSONObject();
		jsonBookObject.put("bookName", "mahabharath");
		jsonBookObject.put("bookCategory", "ithihas");
		jsonArray.add(jsonBookObject);

		JSONObject object = new JSONObject();
		object.put("bookShopsData", array);
		object.put("booksData", jsonArray);

		mockMvc.perform(
				post("/book/addBooks").contentType("application/json;charset=UTF-8").content(object.toString()))
				.andExpect(status().isOk()).andExpect(content().contentType("application/json;charset=UTF-8"))
				.andExpect(jsonPath("$.data[0].bookName",not("politics")));

	}
	/**
	 * test case for adding publisher details with one to one association
	 * @throws Exception
	 */
	@Test 
	public void addPublisherTest() throws Exception {

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("email", "naveen@gmail.com");
		jsonObject.put("address", "hyderqabad");

		JSONObject object = new JSONObject();
		object.put("name", "naveen");
		object.put("publisherDetails", jsonObject);
		mockMvc.perform(
				post("/book/publisher").contentType("application/json;charset=UTF-8").content(object.toString()))
				.andExpect(status().isOk()).andExpect(content().contentType("application/json;charset=UTF-8"));
		
	}

	/**
	 * test  case for adding publisher details with wrong input value using one to one association
	 * @throws Exception
	 */
	@Test 
	public void addPublisherFailureTest() throws Exception {

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("email", "naveen@gmail.com");
		jsonObject.put("address", "hyderqabad");

		JSONObject object = new JSONObject();
		object.put("name", "naveen");
		object.put("publisherDetails", jsonObject);

		
		
		mockMvc.perform(
				post("/book/publisher").contentType("application/json;charset=UTF-8").content(object.toString()))
				.andExpect(content().contentType("application/json;charset=UTF-8"))
				.andExpect(jsonPath("$.data.name", not("vskp")));
	}


}
