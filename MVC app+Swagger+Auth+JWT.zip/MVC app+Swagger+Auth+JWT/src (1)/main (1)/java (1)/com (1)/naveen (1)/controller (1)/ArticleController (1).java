package com.naveen.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.naveen.model.Article;
import com.naveen.model.ArticleAuthorData;
import com.naveen.model.ResponseData;
import com.naveen.service.ArticleService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/article")
@Api(value = "springboot", tags = { "ArticleController" })
public class ArticleController {
	@Autowired
	private ArticleService articleService;
	private static final Logger LOGGER = LogManager.getLogger();

	/**
	 * this method is used to add article details
	 * 
	 * @param article
	 * @return ReposeData<Article>
	 */

	@ApiImplicitParams({
			@ApiImplicitParam(name = "article", value = "article data", required = true, dataType = "Article", paramType = "body") })
	@ApiOperation(value = "Add Article", notes = "Return success response if success, or exception if something wrong", response = Article.class, httpMethod = "POST")
	@ApiResponses(value = { @ApiResponse(code = 201, message = "OK"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 400, message = "Bad Request") })

	//@PreAuthorize("hasAnyRole('USER', 'ADMIN')")
	@PostMapping("/add")
	public ResponseData<Article> addArticle(@RequestBody Article article) {
		ResponseData<Article> response = null;
		try {
			response = articleService.addArticle(article);
			LOGGER.info("article added");

		} catch (Exception e) {
			LOGGER.error("Error in adding article object");
		}
		return response;
	}

	/**
	 * method is used to update the article details
	 * 
	 * @param article
	 * @return ReposeData<Article>
	 */
	@ApiImplicitParams({
			@ApiImplicitParam(name = "article", value = "article data", required = true, dataType = "Article", paramType = "body") })
	@ApiOperation(value = "update Article", notes = "Return success response if success, or exception if something wrong", response = Article.class, httpMethod = "PUT")
	@ApiResponses(value = { @ApiResponse(code = 201, message = "OK"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 400, message = "Bad Request") })

	//@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/update")
	public ResponseData<Article> updateArticle(@RequestBody Article article) {
		ResponseData<Article> response = null;
		try {
			response = articleService.updateArticle(article);
			LOGGER.info("article is updatrd");
		} catch (Exception e) {
			LOGGER.error("Error in updating article object");
		}
		return response;
	}

	/**
	 * method is used to delete the article by articleId
	 * 
	 * @param articleId
	 * @return ReposeData<Article>
	 */

	@ApiOperation(value = "delete Article", notes = "Return success response if success, or exception if something wrong", response = Article.class, httpMethod = "DELETE")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "OK"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 400, message = "Bad Request") })

	//@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/delete")
	public ResponseData<Article> deleteArticle(@RequestParam("articleId") long articleId) {
		ResponseData<Article> response = null;
		try {
			response = articleService.deleteArticle(articleId);
			LOGGER.info("article is deleted");
		} catch (Exception e) {
			LOGGER.error("Error in deleting article object");
		}
		return response;
	}

	/**
	 * method is used retrieve the all article details
	 * 
	 * @return ReposeData<List<Article>>
	 */
	@ApiOperation(value = "get all Article", notes = "Return success response if success, or exception if something wrong", response = Article.class, httpMethod = "GET")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "OK"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 400, message = "Bad Request") })

	//@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/view")
	public ResponseData<List<Article>> getAllArticles() {
		ResponseData<List<Article>> response = null;
		try {
			response = articleService.getAllArticles();
			LOGGER.info(" retrieving articles list is successful");
		} catch (Exception e) {
			LOGGER.error("Error in retrieving article object");
		}
		return response;
	}

	/**
	 * method is used to add articles
	 * 
	 * @param data
	 * @return ReposeData<List<Article>>
	 */
	@ApiImplicitParams({
			@ApiImplicitParam(name = "articlesdata", value = "articles", required = true, dataType = "String", paramType = "body") })
	@ApiOperation(value = "Add Articles", notes = "Return success response if success, or exception if something wrong", response = Article.class, httpMethod = "POST")
	@ApiResponses(value = { @ApiResponse(code = 201, message = "OK"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 400, message = "Bad Request") })

	//@PreAuthorize("hasRole('ADMIN')")

	@PostMapping("/addArticles")
	public ResponseData<List<Article>> addArticles(@RequestBody ArticleAuthorData data) {
		ResponseData<List<Article>> response = null;
		try {
			response = articleService.addArticles(data);
			LOGGER.info("  articles list is added succesfully");
		} catch (Exception e) {
			LOGGER.error("Error in adding articles ");
		}
		return response;
	}

}
