package com.naveen.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.naveen.model.Article;
import com.naveen.model.Book;
import com.naveen.model.Book_BookShopData;
import com.naveen.model.Publisher;
import com.naveen.model.ResponseData;
import com.naveen.service.BookService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/book")
@Api(value="book", tags= {"BookController"})
public class BookController {
	private static final Logger LOGGER = LogManager.getLogger();
	@Autowired
	private BookService bookService;

	/**
	 * method is used to add more books
	 * 
	 * @param data
	 * @return ReposeData<List<Book>>
	 */
	@ApiImplicitParams({@ApiImplicitParam(name="book", value="book data", required=true, dataType="String", paramType="body")})
	@ApiOperation(value = "Add book", notes = "Return success response if success, or exception if something wrong", response = Book.class, httpMethod = "POST")
	@ApiResponses(value = { @ApiResponse(code = 201, message = "OK"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 400, message = "Bad Request") })
	
	//@PreAuthorize("hasRole('USER')")
	@PostMapping("/addBooks")
	public ResponseData<List<Book>> addBooks(@RequestBody Book_BookShopData data) {
		ResponseData<List<Book>> res = null;
		try {
			res = bookService.addBook(data);
			LOGGER.info("Books are added successfully");
		} catch (Exception e) {
			LOGGER.error("books are not added");
		}
		return res;

	}

	/**
	 * method is used to add publisher
	 * 
	 * @param publisher
	 * @return ReposeData<Publisher>
	 */
	@ApiOperation(value = "Add Publisher", notes = "Return success response if success, or exception if something wrong", response = Publisher.class, httpMethod = "POST")
	@ApiResponses(value = { @ApiResponse(code = 201, message = "OK"),
			@ApiResponse(code = 500, message = "Internal Server Error"),
			@ApiResponse(code = 400, message = "Bad Request") })
	
	//@PreAuthorize("hasAnyRole('USER','ADMIN')")
	@PostMapping("/publisher")
	public ResponseData<Publisher> addPublisher(@RequestBody Publisher publisher) {
		ResponseData<Publisher> response = null;

		try {
			response = bookService.addPublisher(publisher);
			LOGGER.info("publisher is added ");

		} catch (Exception e) {
			LOGGER.error("Error in adding publishert object", e);
		}
		return response;
	}
}
