package com.naveen.service;

import java.util.List;

import com.naveen.model.Book;
import com.naveen.model.Book_BookShopData;
import com.naveen.model.Publisher;
import com.naveen.model.ResponseData;

public interface BookService {
	/**
	 * method is used to add books
	 * 
	 * @param data
	 * @return ReposeData<List<Book>>
	 */
	public ResponseData<List<Book>> addBook(Book_BookShopData data);

	/**
	 * method is used to add publisher
	 * 
	 * @param publisher
	 * @return ReposeData<Publisher>
	 */
	public ResponseData<Publisher> addPublisher(Publisher publisher);
}
