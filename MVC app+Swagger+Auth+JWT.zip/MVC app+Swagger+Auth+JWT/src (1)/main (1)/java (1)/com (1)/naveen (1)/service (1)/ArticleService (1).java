package com.naveen.service;

import java.util.List;

import com.naveen.model.Article;
import com.naveen.model.ArticleAuthorData;
import com.naveen.model.ResponseData;

public interface ArticleService {

	/**
	 * method is used to add article
	 * 
	 * @param article
	 * @return ReposeData<Article>
	 */
	public ResponseData<Article> addArticle(Article article);

	/**
	 * method is used to update the article
	 * 
	 * @param article
	 * @return ReposeData<Article>
	 */

	public ResponseData<Article> updateArticle(Article article);

	/**
	 * method is used to delete the article by articleId
	 * 
	 * @param articleId
	 * @return ReposeData<Article>
	 */

	public ResponseData<Article> deleteArticle(long articleId);

	/**
	 * method id used to add articles
	 * 
	 * @param data
	 * @return ReposeData<List<Article>>
	 */
	public ResponseData<List<Article>> addArticles(ArticleAuthorData data);

	/**
	 * method is used to retrieve all articles
	 * 
	 * @return ReposeData<List<Article>>
	 */
	public ResponseData<List<Article>> getAllArticles();

}
