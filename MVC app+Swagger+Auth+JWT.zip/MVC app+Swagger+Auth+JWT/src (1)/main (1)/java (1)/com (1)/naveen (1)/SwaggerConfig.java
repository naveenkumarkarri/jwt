package com.naveen;

import static com.google.common.base.Predicates.or;
import static springfox.documentation.builders.PathSelectors.regex;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.base.Predicate;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Tag;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;


@Configuration
@EnableSwagger2
public class SwaggerConfig {
	 @Bean
	    public Docket productApi() {
	    
	   
	        return new Docket(DocumentationType.SWAGGER_2).useDefaultResponseMessages(false).select()
	                .apis(RequestHandlerSelectors.basePackage("com.naveen.controller")).paths(postPaths()).build()
	              //  .apiInfo(metaData())
	                .tags(new Tag("ArticleController", "Operations pertaining to articles in spring boot project"),
	                        new Tag("BookController", "Operations pertaining to books in spring boot project"));
	    }

	    private Predicate<String> postPaths() {
	        return or(regex("/article.*"), regex("/book.*"));
	    }

//	    private ApiInfo metaData() {
//	        return new ApiInfoBuilder().title("Spring boot REST API")
//	                .description("This is the spring boot Service API Documentation")
//	                .version("1.0.0").license("All rights reserved.").licenseUrl("").build();
//	    }
	}


