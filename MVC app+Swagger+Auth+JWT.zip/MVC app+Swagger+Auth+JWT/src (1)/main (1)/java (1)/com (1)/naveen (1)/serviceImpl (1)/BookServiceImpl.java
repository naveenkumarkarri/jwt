package com.naveen.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.naveen.model.Book;
import com.naveen.model.BookData;
import com.naveen.model.BookShop;
import com.naveen.model.BookShopData;
import com.naveen.model.Book_BookShopData;
import com.naveen.model.Publisher;
import com.naveen.model.ResponseData;
import com.naveen.repository.BookRepository;
import com.naveen.repository.PublisherRepository;
import com.naveen.service.BookService;

@Service
public class BookServiceImpl implements BookService {
	private static final Logger LOGGER = LogManager.getLogger();
	@Autowired
	private BookRepository bookRepository;
	@Autowired
	private PublisherRepository publisherRepository;

	/**
	 * method is used to add books
	 * 
	 * @param data
	 * @return ReposeData<List<Book>>
	 */
	public ResponseData<List<Book>> addBook(Book_BookShopData data) {
		ResponseData<List<Book>> response = new ResponseData<>();
		try {

			List<BookShop> shopList = new ArrayList<>();
			List<BookShopData> list = data.getBookShopsData();
			for (BookShopData bookShopData : list) {
				BookShop bookShop = new BookShop();
				bookShop.setShopName(bookShopData.getShopName());
				bookShop.setShopAddress(bookShopData.getShopAddress());

				shopList.add(bookShop);
			}
			List<Book> bookList = new ArrayList<>();
			List<BookData> bookDataList = data.getBooksData();
			for (BookData bookdata : bookDataList) {
				Book book = new Book();
				book.setBookName(bookdata.getBookName());
				book.setBookCategory(bookdata.getBookCategory());
				book.setBookShops(shopList);
				bookList.add(book);
			}
			List<Book> dbList = bookRepository.saveAll(bookList);
			response.setStatus(201);
			response.setMessage("All books  are added sucessfully");
			response.setData(dbList);
			LOGGER.info("All books  are added sucessfully");
		} catch (Exception e) {
			response.setStatus(204);
			response.setMessage("All books  are added sucessfully");
			response.setData(null);
			LOGGER.info("books  are not added");
		}
		return response;
	}

	/**
	 * method is used to add publisher
	 * 
	 * @param publisher
	 * @return ReposeData<Publisher>
	 */
	@Override
	public ResponseData<Publisher> addPublisher(Publisher publisher) {
		ResponseData<Publisher> response = new ResponseData();
		Publisher savedPublisher;
		try {

			savedPublisher = publisherRepository.save(publisher);
			response.setStatus(201);
			response.setMessage("publisher is added successfully");
			response.setData(savedPublisher);
			LOGGER.info("publisher is added");
		} catch (Exception e) {
			response.setStatus(204);
			response.setMessage("publisher is not added ");
			response.setData(null);
			LOGGER.error("publisher is not added");
		}

		return response;
	}

}
