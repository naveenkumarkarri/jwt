package com.naveen.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.naveen.model.Article;
import com.naveen.model.ArticleAuthorData;
import com.naveen.model.ArticleData;
import com.naveen.model.Author;
import com.naveen.model.AuthorData;
import com.naveen.model.ResponseData;
import com.naveen.repository.ArticleRepository;
import com.naveen.repository.AuthorRepository;
import com.naveen.service.ArticleService;

@Service
public class ArticleServiceImpl implements ArticleService {
	private static final Logger LOGGER = LogManager.getLogger();
	@Autowired
	private ArticleRepository articleRepository;
	@Autowired
	private AuthorRepository authorRepository;

	/**
	 * method is used to add article
	 * 
	 * @param article
	 * @return ReposeData<Article>
	 */
	@Override
	public ResponseData<Article> addArticle(Article article) {
		ResponseData<Article> response = new ResponseData<>();
		try {

			Article articleExists = articleRepository.findByTitle(article.getTitle());

			if (articleExists != null) {
				Article savedArticle = articleRepository.save(article);
				response.setStatus(201);
				response.setMessage("Article is added successfully");
				response.setData(savedArticle);
				LOGGER.info("article added ");
			} else {
				response.setStatus(204);
				response.setMessage("article not added");
				response.setData(null);
				LOGGER.info("article not added");
			}
		} catch (Exception e) {
			response.setStatus(204);
			response.setMessage("article not added");
			response.setData(null);
			LOGGER.error("article is not created");
		}

		return response;
	}

	/**
	 * method is used to update the article
	 * 
	 * @param article
	 * @return ReposeData<Article>
	 */
	@Override
	public ResponseData<Article> updateArticle(Article article) {
		ResponseData<Article> response = new ResponseData<>();
		try {
			Article articleExists = articleRepository.findByArticleId(article.getArticleId());
			if (articleExists != null) {
				Article savedArticle = articleRepository.save(article);
				response.setStatus(201);
				response.setMessage("article is updated successfully");
				response.setData(savedArticle);
				LOGGER.info("article is updated successfully");

			} else {
				response.setStatus(204);
				response.setMessage("article is not updated");
				response.setData(null);
				LOGGER.info("article is not updated by Id");
			}
		} catch (Exception e) {
			response.setStatus(204);
			response.setMessage("article is not updated");
			response.setData(null);
			LOGGER.error("article not updated");
		}
		return response;
	}

	/**
	 * method is used to delete the article by articleId
	 * 
	 * @param articleId
	 * @return ReposeData<Article>
	 */
	@Override
	public ResponseData<Article> deleteArticle(long articleId) {
		ResponseData<Article> response = new ResponseData<>();
		try {
			Article articleExists = articleRepository.findByArticleId(articleId);
			if (articleExists != null) {
				articleRepository.deleteById(articleId);
				response.setStatus(200);
				response.setMessage("article is deleted successfully");
				response.setData(articleExists);
				LOGGER.info("article is deleted successfully");
			} else {
				response.setStatus(204);
				response.setMessage("article is not found");
				response.setData(null);
				LOGGER.info("article is not found by Id");
			}
		} catch (Exception e) {
			response.setStatus(204);
			response.setMessage("article is not found");
			response.setData(null);
			LOGGER.error("article not found");
		}
		return response;
	}

	/**
	 * method is used to retrieve all articles
	 * 
	 * @return ReposeData<List<Article>>
	 */
	public ResponseData<List<Article>> getAllArticles() {
		ResponseData<List<Article>> response = new ResponseData<>();
		try {
			List<Article> allArticles = articleRepository.findAll();
			response.setStatus(200);
			response.setMessage("Getting All articles is successful");
			response.setData(allArticles);
			LOGGER.info("Getting All articles is successful");

		} catch (Exception e) {
			response.setStatus(204);
			response.setMessage("Error in Getting articles ");
			response.setData(null);
			LOGGER.info("Error in Getting articles ");

		}
		return response;

	}

	/**
	 * method id used to add articles
	 * 
	 * @param data 
	 * @return ReposeData<List<Article>>
	 */

	public ResponseData<List<Article>> addArticles(ArticleAuthorData data) {
		ResponseData<List<Article>> response = new ResponseData<>();
		try {
			Author author = new Author();
			AuthorData authorData = data.getAuthorData();
			author.setAuthorName(authorData.getAuthorName());
			Author saved = authorRepository.save(author);

			List<Article> articleList = new ArrayList<>();
			List<ArticleData> list = data.getArticleData();
			for (ArticleData articleData : list) {
				Article article = new Article();
				article.setTitle(articleData.getTitle());
				article.setCategory(articleData.getCategory());
				article.setAuthor(saved);
				articleList.add(article);
			}
			List<Article> dbList = articleRepository.saveAll(articleList);
			response.setStatus(200);
			response.setMessage("All articles  are added sucessfully");
			response.setData(dbList);
			LOGGER.info("All articles  are added sucessfully");
		} catch (Exception e) {
			response.setStatus(204);
			response.setMessage("articles  are not added");
			response.setData(null);
			LOGGER.info("articles  are not added");
		}
		return response;
	}

}
