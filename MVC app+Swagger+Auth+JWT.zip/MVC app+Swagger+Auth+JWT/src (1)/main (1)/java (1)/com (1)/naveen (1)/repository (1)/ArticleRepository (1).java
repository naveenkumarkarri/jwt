package com.naveen.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.naveen.model.Article;

public interface ArticleRepository extends JpaRepository<Article, Long> {
	/** this method is used to find the article by title
	 * @param title
	 * @return title
	 */
	Article findByTitle(String title);

	/**
	 * this method is used to find the article by articleId
	 * @param articleId
	 * @return articleId
	 */
	Article findByArticleId(long articleId);

	/**this method is used to find the article by category
	 * @param category
	 * @return category
	 */
	Article findDistinctByCategory(String category);

	/**
	 * this method is used to find the article by category and title
	 * @param title
	 * @param category
	 * @return title and category
	 */
	Article findByTitleAndCategory(String title, String category);
}
