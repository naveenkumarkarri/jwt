package com.naveen.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.naveen.model.BookShop;

public interface BookShopRepository extends JpaRepository<BookShop, Long>{

}
