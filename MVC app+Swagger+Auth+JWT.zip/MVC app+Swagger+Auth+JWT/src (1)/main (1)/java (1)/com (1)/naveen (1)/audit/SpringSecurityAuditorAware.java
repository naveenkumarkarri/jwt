package com.naveen.audit;

import java.util.Optional;

import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.context.SecurityContextHolder;

public class SpringSecurityAuditorAware implements AuditorAware<String>{


	@Override
	public Optional<String> getCurrentAuditor() {
	org.springframework.security.core.userdetails.User user = (org.springframework.security.core.userdetails.User) SecurityContextHolder
			.getContext().getAuthentication().getPrincipal();
	//com.zone.zissa.model.User userobject = userRepo.findByUserName(user.getUsername());
		return Optional.of(user.getUsername());
		
		
		
		
	
		
	}
}
	
	

