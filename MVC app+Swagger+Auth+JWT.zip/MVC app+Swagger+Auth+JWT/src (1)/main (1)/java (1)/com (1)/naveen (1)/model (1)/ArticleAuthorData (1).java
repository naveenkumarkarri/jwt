package com.naveen.model;

import java.util.List;
import java.util.Set;

public class ArticleAuthorData {
	private AuthorData authorData;
	private List<ArticleData> articleData;
	private List<ArticleData> articlesData;
	//private Set<ArticleData> articlesData;
	private Set<AuthorData> authorsData;

	public AuthorData getAuthorData() {
		return authorData;
	}

	public void setAuthordata(AuthorData authorData) {
		this.authorData = authorData;
	}

	public List<ArticleData> getArticleData() {
		return articleData;
	}

	public void setArticleData(List<ArticleData> articleData) {
		this.articleData = articleData;
	}

	/*public Set<ArticleData> getArticlesData() {
		return articlesData;
	}

	public void setArticlesData(Set<ArticleData> articlesData) {
		this.articlesData = articlesData;
	}*/

	public Set<AuthorData> getAuthorsData() {
		return authorsData;
	}

	public void setAuthorsData(Set<AuthorData> authorsData) {
		this.authorsData = authorsData;
	}

	public List<ArticleData> getArticlesData() {
		return articlesData;
	}

	public void setArticlesData(List<ArticleData> articlesData) {
		this.articlesData = articlesData;
	}

	}
