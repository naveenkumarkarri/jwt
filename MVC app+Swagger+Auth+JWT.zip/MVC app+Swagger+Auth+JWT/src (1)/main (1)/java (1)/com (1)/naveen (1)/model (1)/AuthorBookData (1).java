package com.naveen.model;

import java.util.List;

public class AuthorBookData {
	private AuthorData authordata;
	private BookData bookdata;
	List<AuthorData> authorsdata;
	List<BookData> booksdata;

	public AuthorData getAuthordata() {
		return authordata;
	}

	public void setAuthordata(AuthorData authordata) {
		this.authordata = authordata;
	}

	public BookData getBookdata() {
		return bookdata;
	}

	public void setBookdata(BookData bookdata) {
		this.bookdata = bookdata;
	}

	public List<AuthorData> getAuthorsdata() {
		return authorsdata;
	}

	public void setAuthorsdata(List<AuthorData> authorsdata) {
		this.authorsdata = authorsdata;
	}

	public List<BookData> getBooksdata() {
		return booksdata;
	}

	public void setBooksdata(List<BookData> booksdata) {
		this.booksdata = booksdata;
	}

}
