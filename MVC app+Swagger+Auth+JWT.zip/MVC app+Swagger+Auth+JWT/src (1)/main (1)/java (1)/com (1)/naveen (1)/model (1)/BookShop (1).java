package com.naveen.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
/**
 * The  class BookShop having fields and stored in the database 
 * 
 */
@Entity
public class BookShop {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long shopId;
	private String shopName;
	private String shopAddress;

	@ManyToMany(mappedBy = "bookShops")
	private List<Book> books;

	public long getShopId() {
		return shopId;
	}

	public void setShopId(long shopId) {
		this.shopId = shopId;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getShopAddress() {
		return shopAddress;
	}

	public void setShopAddress(String shopAddress) {
		this.shopAddress = shopAddress;
	}

	

}
