package com.naveen.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
/**
 * The  class Author having fields and stored in the database 
 * 
 */
@Entity
@Table(name = "author")
public class Author {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "author_id")
	private long authorId;

	@Column(name = "author_Name")
	private String authorName;

	

	@OneToMany(mappedBy = "author")
	private List<Article> articles;

	public long getAuthorId() {
		return authorId;
	}

	public void setAuthorId(long authorId) {
		this.authorId = authorId;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
}
/*
 * @ManyToMany( fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST,
 * CascadeType.MERGE },mappedBy = "authors")
 * 
 * @ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST,
 * CascadeType.MERGE ,CascadeType.REFRESH})
 * 
 * @JoinTable(name = "article_author", joinColumns = { @JoinColumn(name =
 * "author_id") }, inverseJoinColumns = { @JoinColumn(name = "article_id") })
 * 
 * private Set<Article> articles ;
 */
/*
 * public Set<Article> getArticles() { return articles; }
 * 
 * public void setArticles(Set<Article> articles) { this.articles = articles; }
 */