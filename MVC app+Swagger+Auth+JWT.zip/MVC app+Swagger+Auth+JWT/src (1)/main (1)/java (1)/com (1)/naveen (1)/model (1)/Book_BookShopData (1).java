package com.naveen.model;

import java.util.List;

public class Book_BookShopData {
	private BookShopData bookShopData;
	private BookData bookData;
	private List<BookShopData> bookShopsData;
	private List<BookData> booksData;
	public BookShopData getBookShopData() {
		return bookShopData;
	}
	public void setBookShopData(BookShopData bookShopData) {
		this.bookShopData = bookShopData;
	}
	public BookData getBookData() {
		return bookData;
	}
	public void setBookData(BookData bookData) {
		this.bookData = bookData;
	}
	public List<BookShopData> getBookShopsData() {
		return bookShopsData;
	}
	public void setBookShopsData(List<BookShopData> bookShopsData) {
		this.bookShopsData = bookShopsData;
	}
	public List<BookData> getBooksData() {
		return booksData;
	}
	public void setBooksData(List<BookData> booksData) {
		this.booksData = booksData;
	}


}
